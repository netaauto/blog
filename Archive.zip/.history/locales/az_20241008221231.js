export default {
  creditCalculator: "Kredit kalkulyatoru",
};
