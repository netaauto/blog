export default {
    "creditCaldulator":"Kredit kalkulyatoru"
}