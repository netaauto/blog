module.exports = {
  i18n: {
    locales: ["en", "az"],
    defaultLocale: "en",
  },
};
