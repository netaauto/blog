import React from "react";
import styles from "./_style.module.css";
import Image from "next/image";

export default function MobileHeader() {
  return (
    <div className={styles.mobileHeader}>
      <div>
        <Image
          src={"/images/burger.png"}
          alt="Netaauto Logo"
          style={{ width: "4.267vw" }}
          width={32}
          height={24}
        />
      </div>
      <div>
        <Image
          src={"/images/mobilelogo.png"}
          alt="Netaauto Logo"
          style={{ width: "7.467vw" }}
          layout="intrinsic"
          width={100}
          height={50}
        />
      </div>
      <div>
        <Image
          src={"/images/mobilelang.png"}
          alt="Netaauto Logo"
          style={{ width: "13.28vw" }}
          layout="intrinsic"
          width={100}
          height={50}
        />
      </div>
    </div>
  );
}
