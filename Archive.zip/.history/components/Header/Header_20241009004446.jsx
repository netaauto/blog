import React from "react";
import DesktopHeader from "./DesktopHeader";
import MobileHeader from "./MobileHeader";
import instance from "@/api";

const fetchData = async () => {
  try {
    const res = await instance.get("/api/getCategories"); // Relative URL kullanıyoruz
    return res.data; // Dönüştürülmüş veriyi döndür
  } catch (error) {
    console.log(error);
    return null; // Hata durumunda null döndür
  }
};

export default async function Header() {
  const data = await fetchData();

  return (
    <>
      <DesktopHeader />
      <MobileHeader />
    </>
  );
}
