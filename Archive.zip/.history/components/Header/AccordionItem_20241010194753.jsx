import Image from "next/image";
import React from "react";

export default function AccordionItem() {
  return (
    <div>
      <div className="flex items-center gap-6">
        <Image src="/images/arrow.png" alt="Arrow" width={16} height={16} />
      </div>
    </div>
  );
}
