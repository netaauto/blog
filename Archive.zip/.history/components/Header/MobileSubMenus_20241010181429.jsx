import Image from 'next/image'
import React from 'react'

export default function MobileSubMenus() {
  return (
<div className="absolute top-0 left-0 w-full text-white min-h-screen bg-[rgba(0, 0, 0, 0.8)]" style={{background:"rgba(0, 0, 0, 0.8)"}}>
  
  <div className='w-full p-6 flex justify-end'>

<Image src={"/images/close.png"} alt="Close" style={{ width: "4.267vw" }} width={32} height={24} />

  </div>


</div>  )
}
