"use client";
import { setIsLanguageModalOpen } from "@/lib/features/header/headerSlice";
import { useAppDispatch, useAppSelector } from "@/lib/hooks";
import Image from "next/image";
import React from "react";

export default function LanguageModal() {
  const { isLanguageModalOpen } = useAppSelector((state) => state.header);
  const dispatch = useAppDispatch();

  if (!isLanguageModalOpen) return null;

  return (
    <div
      className="w-[34.167vw] h-[100vh] fixed top-0 right-0 z-[999] flex justify-center items-center"
      style={{ background: "rgba(0, 0, 0, 0.8)" }}
    >
      <Image
        src="/images/close.png"
        alt="Close"
        width={32}
        height={32}
        className="absolute right-6 top-6 cursor-pointer"
        onClick={() => {
          dispatch(setIsLanguageModalOpen(false));
        }}
      />

      <h2>Selec Language</h2>
      <div className="flex items-center gap-4">
        <Image
          src="/images/az.png"
          alt="Azerbaijan Flag"
          width={48}
          height={48}
        />
      </div>
    </div>
  );
}
