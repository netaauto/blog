import React from 'react'

export default function MobileSubMenus() {
  return (
<div className="absolute top-0 left-0 w-full text-white min-h-screen bg-[rgba(0, 0, 0, 0.8)]" style={{background:"rgba(0, 0, 0, 0.8)"}}>
  MobileSubMenus
</div>  )
}
