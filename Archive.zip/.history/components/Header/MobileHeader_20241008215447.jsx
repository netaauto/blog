import React from "react";
import styles from "./_style.module.css";

export default function MobileHeader() {
  return (
    <div className={styles.mobileHeader}>
      <div></div>
      <div></div>
      <div></div>
    </div>
  );
}
