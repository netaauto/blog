import React from "react";
import styles from "./_style.module.css";
import Image from "next/image";

export default function MobileHeader() {
  return (
    <div className={styles.mobileHeader}>
      <div>
      <Image
        src={"/images/burger.png"}
        alt="Netaauto Logo"
        style={{ width: "4.267vw" }}
        layout="intrinsic"
        width={100}
        height={50}
      />
      </div>
      <div></div>
      <div></div>
    </div>
  );
}
