'use client'
import React from 'react'
import styles from "../Header/_style.module.css";
import Image from "next/image";
import { useTranslations } from 'next-intl';

export default function DesktopHeader() {
  const t = useTranslations("HEADER")
  return (
    <div className={styles.header}>
    <div className={styles.left}>
      <div className={styles.menuItem}>We are Neta</div>
      <div className={styles.menuItem}>Models</div>
      <div className={styles.menuItem}>Explore</div>
      <Link href={"/"} className={styles.menuItem}>
        Test Drive
      </Link>
    </div>
    <div className={styles.center}>
      <Image
        src={"/images/logo.png"}
        alt="Netaauto Logo"
        style={{ width: "2.344vw" }}
        layout="intrinsic"
        width={100}
        height={50}
      />
    </div>
    <div className={styles.right}>
      <Link href={"/"} className={styles.menuItem}>
        {t("creditCalculator")}
      </Link>

      <div className={styles.languageBtn}>
        <Image
          src={"/images/wordicon.png"}
          alt="Word Icon"
          style={{ width: "26px" }}
          layout="intrinsic"
          width={100}
          height={50}
        />
        <div className={styles.menuItem}>Select language</div>
      </div>
    </div>
  </div>
  )
}
