import React from "react";
import styles from '../Header/_style.module.css'
import Image from "next/image";

export default function Header() {
  return <div className={styles.header}>

    <div className={styles.left}>
        <div className={styles.menuItem}>We are Neta</div>
        <div className={styles.menuItem}>Models</div>
        <div className={styles.menuItem}>Explore</div>
        <div className={styles.menuItem}>Test Drive</div>


    </div>
    <div className={styles.center}>

        <Image src={"/images/logo.png"} alt="Netaauto Logo" fill/>



    </div>
    <div className={styles.right}></div>


  </div>;
}
