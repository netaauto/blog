import { Link } from "@/i18n/routing";
import Image from "next/image";
import React, { useState } from "react";

export default function AccordionItem() {
  const [active, setActive] = useState(false);
  return (
    <div>
      <div className="flex items-center gap-6" onClick={() => setActive(!active)}>
        {active ? (
          <Image
            src="/images/activeArrow.png"
            alt="Arrow"
            width={16}
            height={16}
            
          />
        ) : (
          <Image
            src="/images/arrow.png"
            alt="Arrow"
            width={16}
            height={16}
        
          />
        )}

        <span>We Are Neta</span>
      </div>

      {active && (
        <div className="flex flex-col mt-[12px] ml-10 text-[24px] gap-3">
          <Link href="/" className="text-6 font-light">
            Brand Story
          </Link>
          <Link href="/" className="text-6 font-light">
            Brand Story
          </Link>
        </div>
      )}
    </div>
  );
}
