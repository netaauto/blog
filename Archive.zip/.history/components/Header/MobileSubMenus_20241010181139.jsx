import React from 'react'

export default function MobileSubMenus() {
  return (
    <div className='absolute top-0 left-0  w-full h-[100vh] bg-[rgba(0, 0, 0,)]'>MobileSubMenus</div>
  )
}
