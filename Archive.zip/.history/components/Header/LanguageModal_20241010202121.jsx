import React from "react";

export default function LanguageModal() {
  return (
    <div
      className="w-[34.167vw] h-[100vh] fixed top-0 right-0 z-[999] flex justify-center items-center"
      style={{ background: "rgba(0, 0, 0, 0.8)" }}
    >
      LanguageModal
    </div>
  );
}
