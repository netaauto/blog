'use client'
import { useAppDispatch, useAppSelector } from '@/lib/hooks';
import { useLocale, useTranslations } from 'next-intl';
import React from 'react'

export default function DesktopSubMenus() {
    const { data, selectedMenu } = useAppSelector((state) => state.header);
    const dispatch = useAppDispatch()
    const t = useTranslations("HEADER");
    const locale = useLocale()




    const LeftSizeAz =
    selectedMenu && selectedMenu.id === "weAreNeta"
      ? "2.5vw"
      : selectedMenu && selectedMenu.id === "models"
      ? "10.4vw"
      : "17.6vw";

      const LeftSizeEn =
    selectedMenu && selectedMenu.id === "weAreNeta"
      ? "2.5vw"
      : selectedMenu && selectedMenu.id === "models"
      ? "11.6vw"
      : "18.1vw";





  return (
    <div>DesktopSubMenus</div>
  )
}
