import React from "react";
import styles from '../Header/_style.module.css'

export default function Header() {
  return <div className={styles.header}>

    <div className={styles.left}></div>
    <div className={styles.center}></div>
    <div className={styles.right}></div>


  </div>;
}
