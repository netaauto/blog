import React from 'react'

export default function MobileHeader() {
  return (
    <div>MobileHeader</div>
  )
}
