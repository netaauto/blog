"use client";
import React from "react";
import styles from "../Header/_style.module.css";
import Image from "next/image";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/routing";

export default function DesktopHeader() {
  const t = useTranslations("HEADER");
  return (
    <div className={styles.header}>
      <div className={styles.left}>
        <div className={styles.menuItem}>We are Neta</div>
        <div className={styles.menuItem}>Models</div>
        <div className={styles.menuItem}>Explore</div>
        <Link href={"/"} className={styles.menuItem}>
          Test Drive
        </Link>
      </div>
      <div className={styles.center}>
        <Image
          src={"/images/logo.png"}
          alt="Netaauto Logo"
          style={{ width: "2.344vw" }}
          width={34}
          height={26}
        />
      </div>
      <div className={styles.right}>
        <Link href={"/"} className={styles.menuItem}>
          {t("creditCalculator")}
        </Link>

        <div className={styles.languageBtn}>
          <Image
            src={"/images/wordicon.png"}
            alt="Word Icon"
            style={{ width: "26px" }}
            width={100}
            height={100}
          />
          <div className={styles.menuItem}>{t("selectLanguage")}</div>
        </div>
      </div>
    </div>
  );
}
