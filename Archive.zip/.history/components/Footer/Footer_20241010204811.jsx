import React from 'react'

export default function Footer() {
  return (
    <div className='w-full h-[10.885vw] bg-black'>Footer</div>
  )
}
