import { Link } from '@/i18n/routing'
import Image from 'next/image'
import React from 'react'

export default function Footer() {
  return (
    <div className='w-full h-[10.885vw] py-[36px] flex flex-col bg-black px-[5.104vw]'>

        <div className='w-full flex justify-between items-center h-[60px]'>

            <div className='flex gap-6 items-center'>

        <Link href={""} alt=""  className='text-white text-[16px]' >Legal Imprint</Link>
        <Link href={""} alt=""  className='text-white text-[16px]' >Privacy</Link>
        <Link href={""} alt=""  className='text-white text-[16px]' >User Manual</Link>

            </div>


            <div className='flex items-center'>

            <Link href="https://www.youtube.com/@NetaAutoAzerbaijan" alt="Youtube" target='_blank'>
            <Image src='/images/youtube.png' alt='Youtube' width={21} height={21} />
            </Link>


            <Link href="hhttps://www.tiktok.com/@netautoazerbaijan" alt="Youtube" target='_blank'>
            <Image src='/images/tiktok.png' alt='Tiktok' width={21} height={21} />
            </Link>

            </div>


        </div>
        <div className='w-full h-[1px] bg-white'></div>
        <div></div>


    </div>
  )
}
