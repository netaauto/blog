import { Link } from "@/i18n/routing";
import Image from "next/image";
import React from "react";

export default function Footer() {
  return (
    <div className="w-ful  py-[36px] flex flex-col bg-black px-[5.104vw]">
      <div className="w-full flex  flex-col lg:flex-row  justify-between items-start lg:items-center h-[60px]">
        <div className="flex gap-6 items-center">
          <Link
            href={""}
            alt=""
            className="text-white text-[16px] hover:text-[#f65a11]"
          >
            Legal Imprint
          </Link>
          <Link
            href={""}
            alt=""
            className="text-white text-[16px]  hover:text-[#f65a11]"
          >
            Privacy
          </Link>
          <Link
            href={""}
            alt=""
            className="text-white text-[16px]  hover:text-[#f65a11]"
          >
            User Manual
          </Link>


          <Link
            href={"https://netaauto.az/neta-v"}
            alt="NetaV"
            className="text-white text-[16px]  hover:text-[#f65a11]"
          >
            Neta V
          </Link>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href="https://www.youtube.com/@NetaAutoAzerbaijan"
            alt="Youtube"
            target="_blank"
          >
            <Image
              src="/images/youtube.png"
              alt="Youtube"
              width={21}
              height={21}
            />
          </Link>

          <Link
            href="hhttps://www.tiktok.com/@netautoazerbaijan"
            alt="Youtube"
            target="_blank"
          >
            <Image
              src="/images/tiktok.png"
              alt="Tiktok"
              width={21}
              height={21}
            />
          </Link>

          <Link
            href="https://www.facebook.com/profile.php?id=61558734524716"
            alt="Facebook"
            target="_blank"
          >
            <Image
              src="/images/facebook.png"
              alt="Tiktok"
              width={21}
              height={21}
            />
          </Link>

          <Link
            href="https://www.instagram.com/netauto.azerbaijan"
            alt="Instagram"
            target="_blank"
          >
            <Image
              src="/images/instagram.png"
              alt="Tiktok"
              width={21}
              height={21}
            />
          </Link>
        </div>
      </div>
      <div className="hidden lg:flex w-full h-[1px] bg-white"></div>
      <div className="hidden lg:flex  mt-6">
        <Link href={"https://netaauto.az"}>
          <Image
            src="/images/footer_logo.png"
            alt="Netaauto Logo"
            width={34}
            height={26}
            style={{ width: "2.5vw" }}
          />
        </Link>
      </div>
    </div>
  );
}
