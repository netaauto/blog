import { Link } from '@/i18n/routing'
import React from 'react'

export default function Footer() {
  return (
    <div className='w-full h-[10.885vw] py-[24px] flex flex-col bg-black px-[5.104vw]'>

        <div className='w-full flex justify-between items-center h-[80px]'>

            <div className='flex gap-6 items-center'>

        <Link href={""} alt=""  className='text-white text-[16px]' >AAAA</Link>
        <Link href={""} alt=""  className='text-white text-[16px]' >AAAA</Link>
        <Link href={""} alt=""  className='text-white text-[16px]' >AAAA</Link>

            </div>


        </div>
        <div className='w-full h-[1px] bg-white'></div>
        <div></div>


    </div>
  )
}
