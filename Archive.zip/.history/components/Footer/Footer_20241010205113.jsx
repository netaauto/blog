import React from 'react'

export default function Footer() {
  return (
    <div className='w-full h-[10.885vw] flex flex-col bg-black px-[5.104vw]'>

        <div></div>
        <div className='w-full h-[0.52vw] bg-white'></div>
        <div></div>


    </div>
  )
}
