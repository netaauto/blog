import React from 'react'

export default function Footer() {
  return (
    <div className='w-full h-[10.885vw] bg-black px-[5.104vw]'>Footer</div>
  )
}
