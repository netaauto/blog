import instance from "@/api";
import Image from "next/image";



const fetchData = async () => {
  try {
    const res = await instance.get("/api/getDocuments?collection=blog"); // Relative URL kullanıyoruz
    return res.data.data; // Dönüştürülmüş veriyi döndür
  } catch (error) {
    console.log(error);
    return null; // Hata durumunda null döndür
  }
};


export default async  function Home() {

  const data = await fetchData();

console.log(data)


  return (
    <div className="grid grid-rows-[20px_1fr_20px] items-center justify-items-center min-h-screen p-8 pb-20 gap-16 sm:p-20 ">


      
      <h2>Blogs</h2>
    </div>
  );
}
