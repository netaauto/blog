import instance from "@/api";
import Image from "next/image";

const fetchData = async () => {
  try {
    const res = await instance.get("/api/getDocuments?collection=blog"); // Relative URL kullanıyoruz
    return res.data.data; // Dönüştürülmüş veriyi döndür
  } catch (error) {
    console.log(error);
    return null; // Hata durumunda null döndür
  }
};

export default async function Home() {
  const data = await fetchData();

  console.log(data);

  return (
    <div className="p-10 pb-20  sm:p-20 bg-[#e5e5e5] ">
      <h2 className="text-[2.292vw] font-semibold mt-5 text-[#2c2c2c]">
        Blogs
      </h2>

      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3  2xl:grid-cols-4">
        <div className="flex h-[400px] flex-col items-center justify-center p-5 bg-white rounded-lg shadow-md"></div>
        <div className="flex h-[400px] flex-col items-center justify-center p-5 bg-white rounded-lg shadow-md"></div>
        <div className="flex h-[400px] flex-col items-center justify-center p-5 bg-white rounded-lg shadow-md"></div>
        <div className="flex h-[400px] flex-col items-center justify-center p-5 bg-white rounded-lg shadow-md"></div>
        <div className="flex h-[400px] flex-col items-center justify-center p-5 bg-white rounded-lg shadow-md"></div>

      </div>
    </div>
  );
}
