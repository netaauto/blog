import { Prompt } from "next/font/google";
import { NextIntlClientProvider } from "next-intl";
import { getMessages } from "next-intl/server";
import "../globals.css";
import Header from "@/components/Header/Header";
import Head from "next/head";
import StoreProvider from "../StoreProvider";

const prompt = Prompt({
  subsets: ["latin"],
  weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
});

export const metadata = {
  title: "Blog NetaAuto",
  description: "Blog NetaAuto",
  icons: {
    icon: '/favicon.ico', // /public path
  },
};

export default async function RootLayout({ children, params: { locale } }) {
  const messages = await getMessages();

  return (
    <html lang={locale}>
      <StoreProvider>
        <NextIntlClientProvider messages={messages}>
          <Head>
          <link rel="icon" href="/favicon.ico" sizes="any" />
          <meta
              name="viewport"
              content="width=device-width, initial-scale=1.0"
            />
          </Head>
          <body
            suppressHydrationWarning={true}
            className={`${prompt.className} bg-[#e5e5e5]`}
          >
            <Header />
            {children}
          </body>
        </NextIntlClientProvider>
      </StoreProvider>
    </html>
  );
}
