import instance from "@/api";
import { Link } from "@/i18n/routing";
import { getTranslations } from "next-intl/server";
import Image from "next/image";

const fetchData = async () => {
  try {
    const res = await instance.get("/api/getDocuments?collection=blog"); // Relative URL kullanıyoruz
    return res.data.data; // Dönüştürülmüş veriyi döndür
  } catch (error) {
    console.log(error);
    return null; // Hata durumunda null döndür
  }
};

export default async function Home() {
  const t = await getTranslations("BLOG");
  const data = await fetchData();

  console.log(data);

  return (
    <div className="p-10 pb-20  sm:p-20 ">
      <h2 className="text-[2.292vw] font-semibold mt-5 text-[#2c2c2c]">
        {t("title")}
      </h2>

      <div className="grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-2  2xl:grid-cols-3 mt-5">
        {data.map((blog) => {
          return (
            <Link
              href={"#"}
              key={blog.id}
              className="flex h-[400px] flex-col items-center justify-center p-5 bg-white "
            >
              <Image
                src={blog.thumbnail}
                alt="Netaauto Logo"
                style={{width:"100%"}}
                width={300}
                height={200}
              />

            <p>{blog.title}</p>

            </Link>
          );
        })}
      </div>
    </div>
  );
}
