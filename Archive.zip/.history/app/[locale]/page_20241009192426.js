import instance from "@/api";
import Image from "next/image";



const fetchData = async () => {
  try {
    const res = await instance.get("/api/getDocuments?collection=blog"); // Relative URL kullanıyoruz
    return res.data.data; // Dönüştürülmüş veriyi döndür
  } catch (error) {
    console.log(error);
    return null; // Hata durumunda null döndür
  }
};


export default async  function Home() {

  const data = await fetchData();

console.log(data)


  return (
    <div className="bg-[#f5f5f5] container">
      <h2>Blogs</h2>
    </div>
  );
}
