import { Poppins } from "next/font/google";

import "./globals.css";
import Header from "@/components/Header/Header";
import Head from "next/head";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata = {
  title: "Blog NetaAuto",
  description: "Blog NetaAuto",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </Head>
      <body suppressHydrationWarning={true} className={poppins.className}>
        <Header />
        {children}
      </body>
    </html>
  );
}
