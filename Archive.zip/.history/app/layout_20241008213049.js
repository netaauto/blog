import { Prompt } from "next/font/google";

import "./globals.css";
import Header from "@/components/Header/Header";
import Head from "next/head";

const prompt = Prompt({
  subsets: ["latin"],
  weight: ["100","200","300","400", "500", "600", "700","800","900"],
});

export const metadata = {
  title: "Blog NetaAuto",
  description: "Blog NetaAuto",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </Head>
      <body suppressHydrationWarning={true} className={prompt.className}>
        <Header />
        {children}
      </body>
    </html>
  );
}
