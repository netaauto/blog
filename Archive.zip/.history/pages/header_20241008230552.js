// /pages/api/hello.js

export default function handler(req, res) {
    if (req.method === 'GET') {
      // Eğer istek GET ise, 200 durum kodu ile JSON yanıtı dönülüyor
      res.status(200).json({ message: 'Hello, Next.js 14 API!' });
    } else {
      // Diğer HTTP metodları için yanıt
      res.setHeader('Allow', ['GET']);
      res.status(405).end(`Method ${req.method} Not Allowed`);
    }
  }
  